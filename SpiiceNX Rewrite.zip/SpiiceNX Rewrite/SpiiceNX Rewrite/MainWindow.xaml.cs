﻿using ICSharpCode.AvalonEdit;
using ICSharpCode.AvalonEdit.Highlighting;
using ICSharpCode.AvalonEdit.Highlighting.Xshd;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using ICSharpCode.AvalonEdit.Search;
using System.Windows.Threading;
using ScriptList;
using System.Diagnostics;
using System.Net;
using DiscordRpcDemo;
using System.Windows.Media.Effects;
using WeAreDevs_API;
using Microsoft.Win32;

namespace SpiiceNX_Rewrite
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static WebClient webclient = new WebClient();
        private DispatcherTimer FileLoad;
        private DispatcherTimer AutoAttach;
        private DispatcherTimer IfInjected;
        private DispatcherTimer FadeInOut;
        private ScrollViewer tabScroller;
        private Discord.EventHandlers handlers;
        private Discord.RichPresence presence;
        readonly ExploitAPI api = new ExploitAPI();
        public MainWindow()
        {
            InitializeComponent();
            SearchPanel.Install(AvalonText);
            Stream high = File.OpenRead("./bin/Syntax.xshd");
            XmlTextReader xtr = new XmlTextReader(high);
            AvalonText.SyntaxHighlighting = HighlightingLoader.Load(xtr, HighlightingManager.Instance);
            //Hide Visibility
            set.Visibility = Visibility.Hidden;
            SideSet.Visibility = Visibility.Hidden;
            //Timer
            Timers();
            //Update Check
            UpdateCheck();
            //Saved Settings Loaded
            //TopMost
            TopMostLoad();
            //AutoAttach
            AutoAttachLoad();
            // DiscordRPC Toggle
            DiscordLoad();
            //Custom Coloring
            ColorLoad();
            //Intro
            Intro();
            //Tabs
            this.EditTabs.Loaded += delegate (object source, RoutedEventArgs e)
            {
                this.EditTabs.GetTemplateItem<Button>("AddTabButton").Click += delegate (object s, RoutedEventArgs f)
                {
                    this.MakeTab("", "New Tab");
                };

                TabItem ti = EditTabs.SelectedItem as TabItem;
                ti.GetTemplateItem<Button>("CloseButton").Visibility = Visibility.Hidden;
                ti.GetTemplateItem<Button>("CloseButton").Width = 0;
                ti.Header = "Main Tab";

                this.tabScroller = this.EditTabs.GetTemplateItem<ScrollViewer>("TabScrollViewer");
            };
        }
        BlurEffect myEffect = new BlurEffect();

        private async void UpdateCheck()
        {
            string curVersionLink = "https://pastebin.com/raw/85RxsqXA";
            string vers = File.ReadAllText("bin/Version");
            WebClient check = new WebClient();
            string curVersionRaw = check.DownloadString(curVersionLink);
            if (curVersionRaw == vers)
            {
                //Good for now :)
            }
            else
            {
                await Task.Delay(TimeSpan.FromSeconds(2));
                SideSet.Height = 268;
                SideSet.Visibility = Visibility.Visible;
                DoubleAnimation animation = new DoubleAnimation();
                animation.From = new double?(0);
                animation.To = new double?(98);
                animation.EasingFunction = new QuarticEase();
                animation.Duration = TimeSpan.FromSeconds(5);
                SideSet.BeginAnimation(FrameworkElement.WidthProperty, animation);
                Update.Opacity = 0;
                DoubleAnimation c = new DoubleAnimation(0, (Duration)TimeSpan.FromSeconds(1));
                c.EasingFunction = new QuarticEase();
                Main.BeginAnimation(FrameworkElement.OpacityProperty, c);
                await Task.Delay(TimeSpan.FromSeconds(2));
                Main.Opacity = 0;
                Main.Visibility = Visibility.Hidden;
                Update.Visibility = Visibility.Visible;
                DoubleAnimation cc = new DoubleAnimation(1, (Duration)TimeSpan.FromSeconds(1));
                cc.EasingFunction = new QuarticEase();
                Update.BeginAnimation(FrameworkElement.OpacityProperty, cc);
            }
        }
        private void Timers()
        {
            // AutomaticFileLoader
            FileLoad = new DispatcherTimer();
            FileLoad.Interval = new TimeSpan(0, 0, 0, 0, 5);
            FileLoad.Tick += FileLoad_Tick;
            FileLoad.Start();
            // AutoAttach
            AutoAttach = new DispatcherTimer();
            AutoAttach.Interval = new TimeSpan(0, 0, 0, 1);
            AutoAttach.Tick += AutoAttach_Tick;
            // FadeInOut
            FadeInOut = new DispatcherTimer();
            FadeInOut.Interval = new TimeSpan(0, 0, 0, 3);
            FadeInOut.Tick += FadeInOut_Tick;
            // If Injected
            IfInjected = new DispatcherTimer();
            IfInjected.Interval = new TimeSpan(0, 0, 0, 3);
            IfInjected.Tick += IfInjected_Tick;
            IfInjected.Start();
        }

        private void IfInjected_Tick(object sender, EventArgs e)
        {
            CheckInjected();
        }

        private void CheckInjected()
        {
            if (api.isAPIAttached())
            {
                DoubleAnimation cc = new DoubleAnimation(0, (Duration)TimeSpan.FromSeconds(3));
                cc.EasingFunction = new QuarticEase();
                Inject.BeginAnimation(FrameworkElement.OpacityProperty, cc);
            }
            else
            {
                DoubleAnimation cc = new DoubleAnimation(1, (Duration)TimeSpan.FromSeconds(3));
                cc.EasingFunction = new QuarticEase();
                Inject.BeginAnimation(FrameworkElement.OpacityProperty, cc);
            }
        }

        private void TopMostLoad()
        {
            string topmost = File.ReadAllText("bin/TopMost");
            if (topmost == "true")
            {
                this.Topmost = true;
                TopMost.Content = "TopMost✔️";
            }
            else
            {
                this.Topmost = false;
                TopMost.Content = "TopMost❌";
            }
        }
        private void AutoAttachLoad()
        {
            //AutoAttach
            string autoattach = File.ReadAllText("bin/AutoAttach");
            if (autoattach == "true")
            {
                AutoAttach.Start();
                AutoAttachh.Content = "AutoAttach✔️";
            }
            else
            {
                AutoAttachh.Content = "AutoAttach❌";
            }
        }
        private void DiscordLoad()
        {
            string discordrpc = File.ReadAllText("bin/DiscordRPC");
            if (discordrpc == "true")
            {
                this.handlers = default(Discord.EventHandlers);
                Discord.Initialize("755226718238670922", ref this.handlers, true, null);
                this.handlers = default(Discord.EventHandlers);
                Discord.Initialize("755226718238670922", ref this.handlers, true, null);
                this.presence.details = "Scripting Utility of the Future! (Alpha)";
                this.presence.state = "Using SpiiceNX";
                this.presence.largeImageKey = "logo";
                Discord.UpdatePresence(ref this.presence);
                DiscordBTN.Content = "DiscordRPC✔️";
            }
            else if (discordrpc == "false")
            {
                Discord.Shutdown(ref this.presence);
                DiscordBTN.Content = "DiscordRPC❌";
            }
        }
        private void ColorLoad()
        {
            //Custom Coloring
            string noo = File.ReadAllText("bin/rgb/r");
            string no = File.ReadAllText("bin/rgb/g");
            string n = File.ReadAllText("bin/rgb/b");
            string color = File.ReadAllText("bin/Color");
            string yes = noo;
            string ye = no;
            string y = n;
            if (color == "default")
            {
                _1.Text = yes;
                _2.Text = ye;
                _3.Text = y;
            }
            else
            {
                byte r = Convert.ToByte(yes);
                byte g = Convert.ToByte(ye);
                byte b = Convert.ToByte(y);
                LinearGradientBrush gradientBrush = new LinearGradientBrush(Color.FromArgb(100, 0, 0, 0), Color.FromArgb(80, 31, 191, 23),
                    new Point(0.5, 0), new Point(0.5, 1));
                Drid.Background = gradientBrush;
                var brush = new SolidColorBrush(Color.FromArgb(255, (byte)r, (byte)g, (byte)b));
                border.Background = brush;
                var brus = new SolidColorBrush(Color.FromArgb(80, (byte)r, (byte)g, (byte)b));
                rectangle.Fill = brus;
                _1.Text = yes;
                _2.Text = ye;
                _3.Text = y;
            }
        }
        private async void Intro()
        {
            string intro = File.ReadAllText("bin/Intro");
            if (intro == "true")
            {
                Beginning.Content = "Intro✔️";
                TinyLogo.Opacity = 0;
                Blur.Visibility = Visibility.Visible;
                LogoImage.Visibility = Visibility.Visible;
                Version.Visibility = Visibility.Visible;
                myEffect.Radius = 40;
                Blur.Effect = myEffect;
                Blur.Opacity = 0;
                await Task.Delay(TimeSpan.FromSeconds(1));
                DoubleAnimation d = new DoubleAnimation(1, (Duration)TimeSpan.FromSeconds(7));
                d.EasingFunction = new QuarticEase();
                Blur.BeginAnimation(FrameworkElement.OpacityProperty, d);
                await Task.Delay(TimeSpan.FromSeconds(4));
                DoubleAnimation dd = new DoubleAnimation(0, (Duration)TimeSpan.FromSeconds(3));
                dd.EasingFunction = new QuarticEase();
                Blur.BeginAnimation(FrameworkElement.OpacityProperty, dd);
                LogoImage.BeginAnimation(FrameworkElement.OpacityProperty, dd);
                Version.BeginAnimation(FrameworkElement.OpacityProperty, dd);
                TinyLogo.BeginAnimation(FrameworkElement.OpacityProperty, d);
                await Task.Delay(TimeSpan.FromSeconds(2));
                Blur.Visibility = Visibility.Hidden;
                LogoImage.Visibility = Visibility.Hidden;
                Version.Visibility = Visibility.Hidden;
            }
            else if (intro == "false")
            {
                Beginning.Content = "Intro❌";
            }
        }
        private async void FadeInOut_Tick(object sender, EventArgs e)
        {
            DoubleAnimation d = new DoubleAnimation(0.7, (Duration)TimeSpan.FromSeconds(3));
            d.EasingFunction = new QuarticEase();
            Credits.BeginAnimation(FrameworkElement.OpacityProperty, d);
            await Task.Delay(TimeSpan.FromSeconds(1));
            //Fade in
            DoubleAnimation ee = new DoubleAnimation(1, (Duration)TimeSpan.FromSeconds(3));
            ee.EasingFunction = new QuarticEase();
            Credits.BeginAnimation(FrameworkElement.OpacityProperty, ee);
            await Task.Delay(TimeSpan.FromSeconds(1));
        }

        private void AutoAttach_Tick(object sender, EventArgs e)
        {
            if (Process.GetProcessesByName("RobloxPlayerLauncher").Length == 0 && Process.GetProcessesByName("RobloxPlayerBeta").Length != 0)
            {
                if (api.isAPIAttached())
                {
                    DoubleAnimation cc = new DoubleAnimation(0, (Duration)TimeSpan.FromSeconds(3));
                    cc.EasingFunction = new QuarticEase();
                    Inject.BeginAnimation(FrameworkElement.OpacityProperty, cc);
                }
                else
                {
                    DoubleAnimation cc = new DoubleAnimation(1, (Duration)TimeSpan.FromSeconds(3));
                    cc.EasingFunction = new QuarticEase();
                    Inject.BeginAnimation(FrameworkElement.OpacityProperty, cc);
                    api.LaunchExploit();
                }
            }
        }

        private void FileLoad_Tick(object sender, EventArgs e)
        {
            list.Items.Clear();
            Functions.PopulateListBox(list, "./scripts", "*.txt");
            Functions.PopulateListBox(list, "./scripts", "*.lua");
            FileLoad.Stop();
        }

        private async void Button_MouseEnter(object sender, MouseEventArgs e)
        {
            //Fade Out OpenSet (Long Rectangle)
            DoubleAnimation c = new DoubleAnimation(0, (Duration)TimeSpan.FromSeconds(1));
            c.EasingFunction = new QuarticEase();
            OpenSet.BeginAnimation(FrameworkElement.OpacityProperty, c);
            await Task.Delay(TimeSpan.FromSeconds(0.5));
            OpenSet.Visibility = Visibility.Hidden;
            set.Visibility = Visibility.Visible;
            //Slide in Setting Bar
            DoubleAnimation animation = new DoubleAnimation();
            animation.From = new double?(0);
            animation.To = new double?(31);
            animation.EasingFunction = new QuarticEase();
            animation.Duration = TimeSpan.FromSeconds(5);
            set.BeginAnimation(FrameworkElement.HeightProperty, animation);
            //set.Visibility = Visibility.Visible;
            //OpenSet.Visibility = Visibility.Hidden;

            //Slide out Setting Bar
            await Task.Delay(TimeSpan.FromSeconds(5));
            DoubleAnimation animatio = new DoubleAnimation();
            animatio.From = new double?(31);
            animatio.To = new double?(0);
            animatio.EasingFunction = new QuarticEase();
            animatio.Duration = TimeSpan.FromSeconds(5);
            set.BeginAnimation(FrameworkElement.HeightProperty, animatio);
            //Fade in OpenSet (Long Rectangle)
            OpenSet.Visibility = Visibility.Visible;
            DoubleAnimation a = new DoubleAnimation(1, (Duration)TimeSpan.FromSeconds(1));
            a.EasingFunction = new QuarticEase();
            OpenSet.BeginAnimation(FrameworkElement.OpacityProperty, a);
            await Task.Delay(TimeSpan.FromSeconds(0.5));
            //OpenSet.Visibility = Visibility.Visible;
            //set.Visibility = Visibility.Hidden;
            //OpenSet.Visibility = Visibility.Visible;
        }

        private void Rectangle_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                DragMove();
            }
        }

        private void Rectangle_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            //DoubleAnimation animation = new DoubleAnimation();
            //animation.From = new double?(740.5);
            //animation.To = new double?(0);
            //animation.EasingFunction = new QuarticEase();
            //animation.Duration = TimeSpan.FromSeconds(5);
            //grid.BeginAnimation(FrameworkElement.WidthProperty, animation);
            this.WindowState = WindowState.Minimized;
            //BeginStoryboard sb = this.FindResource("Load") as BeginStoryboard;
            //sb.Storyboard.Begin();
        }

        private async void Rectangle_MouseDown_2(object sender, MouseButtonEventArgs e)
        {
            DoubleAnimation d = new DoubleAnimation(0, (Duration)TimeSpan.FromSeconds(1));
            d.EasingFunction = new QuarticEase();
            grid.BeginAnimation(FrameworkElement.OpacityProperty, d);
            await Task.Delay(TimeSpan.FromSeconds(1));
            this.Close();
        }
        private void DropTab(object sender, DragEventArgs e)
        {
            TabItem tabItem = e.Source as TabItem;
            if (tabItem != null)
            {
                TabItem tabItem2 = e.Data.GetData(typeof(TabItem)) as TabItem;
                if (tabItem2 != null)
                {
                    if (!tabItem.Equals(tabItem2))
                    {
                        TabControl tabControl = tabItem.Parent as TabControl;
                        int insertIndex = tabControl.Items.IndexOf(tabItem2);
                        int num = tabControl.Items.IndexOf(tabItem);
                        tabControl.Items.Remove(tabItem2);
                        tabControl.Items.Insert(num, tabItem2);
                        tabControl.Items.Remove(tabItem);
                        tabControl.Items.Insert(insertIndex, tabItem);
                        tabControl.SelectedIndex = num;
                    }
                    return;
                }
            }
        }

        private void ScrollTabs(object sender, MouseWheelEventArgs e)
        {
            this.tabScroller.ScrollToHorizontalOffset(this.tabScroller.HorizontalOffset + (double)(e.Delta / 10));
        }

        private void MoveTab(object sender, MouseEventArgs e)
        {
            TabItem tabItem = e.Source as TabItem;
            if (tabItem == null)
            {
                return;
            }
            if (Mouse.PrimaryDevice.LeftButton == MouseButtonState.Pressed)
            {
                if (VisualTreeHelper.HitTest(tabItem, Mouse.GetPosition(tabItem)).VisualHit is Button)
                {
                    return;
                }
                DragDrop.DoDragDrop(tabItem, tabItem, DragDropEffects.Move);
            }
        }

        private TextEditor current;

        public TextEditor GetCurrent()
        {
            if (this.EditTabs.Items.Count == 0)
            {
                return AvalonText;
            }
            else
            {
                return this.current = (this.EditTabs.SelectedContent as TextEditor);
            }
        }

        public TextEditor MakeEditor()
        {
            TextEditor textEditor = new TextEditor
            {
                ShowLineNumbers = true,
                Background = new SolidColorBrush(Color.FromRgb(33, 33, 33)),
                Foreground = new SolidColorBrush(Color.FromRgb(255, 255, byte.MaxValue)),
                Margin = new Thickness(-2, -1, 0, 0),
                FontFamily = new FontFamily("Consolas"),
                Style = (this.TryFindResource("Avalon") as Style),
                HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto
            };
            textEditor.Options.EnableEmailHyperlinks = false;
            textEditor.Options.EnableHyperlinks = false;
            textEditor.Options.AllowScrollBelowDocument = true;
            Stream xshd_stream = File.OpenRead(Environment.CurrentDirectory + @"\bin\" + "Syntax.xshd");
            XmlTextReader xshd_reader = new XmlTextReader(xshd_stream);
            textEditor.SyntaxHighlighting = HighlightingLoader.Load(xshd_reader, HighlightingManager.Instance);

            xshd_reader.Close();
            xshd_stream.Close();
            return textEditor;
        }

        public TabItem MakeTab(string text = "", string title = "Tab")
        {
            title = title + " " + EditTabs.Items.Count.ToString();
            bool loaded = false;
            TextEditor textEditor = MakeEditor();
            textEditor.Text = text;
            TabItem tab = new TabItem
            {
                Content = textEditor,
                Style = (base.TryFindResource("Tab") as Style),
                AllowDrop = true,
                Header = title
            };
            tab.MouseWheel += this.ScrollTabs;
            tab.Loaded += delegate (object source, RoutedEventArgs e)
            {
                if (loaded)
                {
                    return;
                }
                this.tabScroller.ScrollToRightEnd();
                loaded = true;
            };
            tab.MouseDown += delegate (object sender, MouseButtonEventArgs e)
            {
                if (e.OriginalSource is Border)
                {
                    if (e.MiddleButton == MouseButtonState.Pressed)
                    {
                        this.EditTabs.Items.Remove(tab);
                        return;
                    }
                }
            };

            tab.Loaded += delegate (object s, RoutedEventArgs e)
            {
                tab.GetTemplateItem<Button>("CloseButton").Click += delegate (object r, RoutedEventArgs f)
                {
                    this.EditTabs.Items.Remove(tab);
                };

                this.tabScroller.ScrollToRightEnd();
                loaded = true;
            };

            tab.MouseMove += this.MoveTab;
            tab.Drop += this.DropTab;
            string oldHeader = title;
            this.EditTabs.SelectedIndex = this.EditTabs.Items.Add(tab);
            return tab;
        }

        private async void Button_Click_1(object sender, RoutedEventArgs e)
        {
            DoubleAnimation d = new DoubleAnimation(0, (Duration)TimeSpan.FromSeconds(1));
            d.EasingFunction = new QuarticEase();
            grid.BeginAnimation(FrameworkElement.OpacityProperty, d);
            await Task.Delay(TimeSpan.FromSeconds(1));
            this.Close();
        }

        private void rectangle_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void list_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            GetCurrent().Text = File.ReadAllText($"./scripts/{list.SelectedItem}");
        }

        private void PART_LineUpButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            list.Items.Clear();
            Functions.PopulateListBox(list, "./scripts", "*.txt");
            Functions.PopulateListBox(list, "./scripts", "*.lua");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }


        private async void Button_Click_3(object sender, RoutedEventArgs e)
        {
            if (SideSet.Visibility == Visibility.Visible)
            {
                DoubleAnimation animation = new DoubleAnimation();
                animation.From = new double?(98);
                animation.To = new double?(0);
                animation.EasingFunction = new QuarticEase();
                animation.Duration = TimeSpan.FromSeconds(5);
                SideSet.BeginAnimation(FrameworkElement.WidthProperty, animation);
                await Task.Delay(TimeSpan.FromSeconds(3));
                SideSet.Visibility = Visibility.Hidden;
            }
            else
            {
                SideSet.Height = 268;
                SideSet.Visibility = Visibility.Visible;
                DoubleAnimation animation = new DoubleAnimation();
                animation.From = new double?(0);
                animation.To = new double?(98);
                animation.EasingFunction = new QuarticEase();
                animation.Duration = TimeSpan.FromSeconds(5);
                SideSet.BeginAnimation(FrameworkElement.WidthProperty, animation);
                if (SideSet.Height == 230)
                {
                    DoubleAnimation animatin = new DoubleAnimation();
                    animatin.From = new double?(230);
                    animatin.To = new double?(268);
                    animatin.EasingFunction = new QuarticEase();
                    animatin.Duration = TimeSpan.FromSeconds(1);
                    SideSet.BeginAnimation(FrameworkElement.HeightProperty, animatin);
                }
            }
            
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            string text = File.ReadAllText("bin/TopMost");
            if (text == "false")
            {
                File.WriteAllText("bin/TopMost", "true");
                this.Topmost = true;
                TopMost.Content = "TopMost✔️";
            }
            else if (text == "true")
            {
                File.WriteAllText("bin/TopMost", "false");
                this.Topmost = false;
                TopMost.Content = "TopMost❌";
            }
        }

        private void TopMost_Copy1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string color1 = _1.Text;
                string color2 = _2.Text;
                string color3 = _3.Text;
                byte yes = Convert.ToByte(color1);
                byte ye = Convert.ToByte(color2);
                byte y = Convert.ToByte(color3);
                File.WriteAllText("bin/rgb/r", _1.Text);
                File.WriteAllText("bin/rgb/g", _2.Text);
                File.WriteAllText("bin/rgb/b", _3.Text);
                File.WriteAllText("bin/Color", "false");
                LinearGradientBrush gradientBrush = new LinearGradientBrush(Color.FromArgb(100, 0, 0, 0), Color.FromArgb(80, 31, 191, 23),
                    new Point(0.5, 0), new Point(0.5, 1));
                Drid.Background = gradientBrush;
                var brush = new SolidColorBrush(Color.FromArgb(255, (byte)yes, (byte)ye, (byte)y));
                border.Background = brush;
                var brus = new SolidColorBrush(Color.FromArgb(80, (byte)yes, (byte)ye, (byte)y));
                rectangle.Fill = brus;

            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message, "SpiiceNX");
            }
        }

        private void TopMost_Copy_Click(object sender, RoutedEventArgs e)
        {
            Process[] processesByName = Process.GetProcessesByName("RobloxPlayerBeta");
            int num = 0;
            for (int i = 0; i < processesByName.Length; i++)
            {
                processesByName[i].Kill();
                num++;
            }
            MessageBox.Show($"Killed {num} Roblox Processes", "SpiiceNX");
        }

        private void TopMost_Copy2_Click(object sender, RoutedEventArgs e)
        {
            string text = File.ReadAllText("bin/AutoAttach");
            if (text == "false")
            {
                File.WriteAllText("bin/AutoAttach", "true");
                AutoAttach.Start();
                AutoAttachh.Content = "AutoAttach✔️";
            }
            else if (text == "true")
            {
                File.WriteAllText("bin/AutoAttach", "false");
                AutoAttach.Stop();
                AutoAttachh.Content = "AutoAttach❌";
            }
        }

        private void Image_MouseDown(object sender, MouseButtonEventArgs e)
        {
            FadeInOut.Start();
            Credits.Visibility = Visibility.Visible;
            Credits.Opacity = 0;
            DoubleAnimation ee = new DoubleAnimation(1, (Duration)TimeSpan.FromSeconds(3));
            ee.EasingFunction = new QuarticEase();
            Credits.BeginAnimation(FrameworkElement.OpacityProperty, ee);
        }

        private async void Button_Click_5(object sender, RoutedEventArgs e)
        {
            FadeInOut.Stop();
            DoubleAnimation d = new DoubleAnimation(0, (Duration)TimeSpan.FromSeconds(1));
            d.EasingFunction = new QuarticEase();
            Credits.BeginAnimation(FrameworkElement.OpacityProperty, d);
            await Task.Delay(TimeSpan.FromSeconds(1));
            Credits.Visibility = Visibility.Hidden;
        }

        private async void OpenSet_Copy_MouseEnter(object sender, MouseEventArgs e)
        {
            //Fade Out OpenSet (Long Rectangle)
            DoubleAnimation c = new DoubleAnimation(0, (Duration)TimeSpan.FromSeconds(1));
            c.EasingFunction = new QuarticEase();
            CloseSet.BeginAnimation(FrameworkElement.OpacityProperty, c);
            await Task.Delay(TimeSpan.FromSeconds(0.5));
            CloseSet.Visibility = Visibility.Hidden;
            SideSet.Visibility = Visibility.Visible;
            //Slide in Setting Bar
            DoubleAnimation animatin = new DoubleAnimation();
            animatin.From = new double?(268);
            animatin.To = new double?(230);
            animatin.EasingFunction = new QuarticEase();
            animatin.Duration = TimeSpan.FromSeconds(5);
            SideSet.BeginAnimation(FrameworkElement.HeightProperty, animatin);
            await Task.Delay(TimeSpan.FromSeconds(2));
            DoubleAnimation animation = new DoubleAnimation();
            animation.From = new double?(98);
            animation.To = new double?(0);
            animation.EasingFunction = new QuarticEase();
            animation.Duration = TimeSpan.FromSeconds(5);
            SideSet.BeginAnimation(FrameworkElement.WidthProperty, animation);
            //set.Visibility = Visibility.Visible;
            //SideSet.Visibility = Visibility.Hidden;
            //Fade in OpenSet (Long Rectangle)
            DoubleAnimation a = new DoubleAnimation(1, (Duration)TimeSpan.FromSeconds(1));
            a.EasingFunction = new QuarticEase();
            CloseSet.BeginAnimation(FrameworkElement.OpacityProperty, a);
            await Task.Delay(TimeSpan.FromSeconds(3));
            CloseSet.Visibility = Visibility.Visible;
            SideSet.Height = 268;
            SideSet.Visibility = Visibility.Hidden;
            //set.Visibility = Visibility.Hidden;
            //OpenSet.Visibility = Visibility.Visible;
            //
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            try
            {
                string raw = Raw1.Text;
                string yes = "https://pastebin.com/raw/" + raw;
                if (Raw1.Text.Contains("https://pastebin.com/raw/"))
                {
                    string ok = Raw1.Text.Replace("https://pastebin.com/raw/", "");
                    yes = "https://pastebin.com/raw/" + ok;
                }
                else if (Raw1.Text.Contains("https://pastebin.com/"))
                {
                    string okk = Raw1.Text.Replace("https://pastebin.com/", "");
                    yes = "https://pastebin.com/raw/" + okk;
                }
                else
                {
                    yes = "https://pastebin.com/raw/" + raw;
                }
                //string ok = Raw1.Text.Replace("https://pastebin.com/raw/", "");
                string text = webclient.DownloadString(yes);
                api.SendLuaScript(text);
                History.Items.Add(yes);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message, "SpiiceNX");
            }
            
        }

        private void History_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string rem = (string)History.SelectedItem;
            //string re = "https://pastebin.com/raw/";
            Raw1.Text = rem.Remove(0, 25);
        }

        private void Raw1_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Raw1.Text.Contains("https://pastebin.com/raw/"))
            {
                Raw1.FontSize = 5.5;
            }
            else if (Raw1.Text.Contains("https://pastebin.com/"))
            {
                Raw1.FontSize = 6;
            }
            else
            {
                Raw1.FontSize = 11;
            }

        }

        private async void Button_Click_7(object sender, RoutedEventArgs e)
        {
            Main.Opacity = 0;
            DoubleAnimation c = new DoubleAnimation(0, (Duration)TimeSpan.FromSeconds(1));
            c.EasingFunction = new QuarticEase();
            Raw.BeginAnimation(FrameworkElement.OpacityProperty, c);
            await Task.Delay(TimeSpan.FromSeconds(2));
            Raw.Opacity = 0;
            Raw.Visibility = Visibility.Hidden;
            Main.Visibility = Visibility.Visible;
            DoubleAnimation cc = new DoubleAnimation(1, (Duration)TimeSpan.FromSeconds(1));
            cc.EasingFunction = new QuarticEase();
            Main.BeginAnimation(FrameworkElement.OpacityProperty, cc);
        }

        private async void Button_Click_8(object sender, RoutedEventArgs e)
        {
            Raw.Opacity = 0;
            DoubleAnimation c = new DoubleAnimation(0, (Duration)TimeSpan.FromSeconds(1));
            c.EasingFunction = new QuarticEase();
            Main.BeginAnimation(FrameworkElement.OpacityProperty, c);
            await Task.Delay(TimeSpan.FromSeconds(2));
            Main.Opacity = 0;
            Main.Visibility = Visibility.Hidden;
            Raw.Visibility = Visibility.Visible;
            DoubleAnimation cc = new DoubleAnimation(1, (Duration)TimeSpan.FromSeconds(1));
            cc.EasingFunction = new QuarticEase();
            Raw.BeginAnimation(FrameworkElement.OpacityProperty, cc);
        }

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            string text = File.ReadAllText("bin/Color");
            File.WriteAllText("bin/Color", "default");
            MessageBox.Show("Inorder for this to take change please reopen the program", "SpiiceNX");
        }

        private void DiscordBTN_Click(object sender, RoutedEventArgs e)
        {
            string text = File.ReadAllText("bin/DiscordRPC");
            if (text == "false")
            {
                File.WriteAllText("bin/DiscordRPC", "true");
                this.handlers = default(Discord.EventHandlers);
                Discord.Initialize("755226718238670922", ref this.handlers, true, null);
                this.handlers = default(Discord.EventHandlers);
                Discord.Initialize("755226718238670922", ref this.handlers, true, null);
                this.presence.details = "Scripting Utility of the Future! (Alpha)";
                this.presence.state = "Using SpiiceNX";
                this.presence.largeImageKey = "logo";
                Discord.UpdatePresence(ref this.presence);
                DiscordBTN.Content = "DiscordRPC✔️";
            }
            else if (text == "true")
            {
                File.WriteAllText("bin/DiscordRPC", "false");
                Discord.Shutdown(ref this.presence);
                DiscordBTN.Content = "DiscordRPC❌";
            }
        }

        private void Beginning_Click(object sender, RoutedEventArgs e)
        {
            string intro = File.ReadAllText("bin/Intro");
            if (intro == "true")
            {
                File.WriteAllText("bin/Intro", "false");
                Beginning.Content = "Intro❌";
            }
            else if (intro == "false")
            {
                File.WriteAllText("bin/Intro", "true");
                Beginning.Content = "Intro✔️";
            }
        }

        private void Button_Click_10(object sender, RoutedEventArgs e)
        {
            try
            {
                string raw = Raw1.Text;
                _ = "https://pastebin.com/raw/" + raw;
                string yes;
                if (Raw1.Text.Contains("https://pastebin.com/raw/"))
                {
                    string ok = Raw1.Text.Replace("https://pastebin.com/raw/", "");
                    yes = "https://pastebin.com/raw/" + ok;
                }
                else if (Raw1.Text.Contains("https://pastebin.com/"))
                {
                    string okk = Raw1.Text.Replace("https://pastebin.com/", "");
                    yes = "https://pastebin.com/raw/" + okk;
                }
                else
                {
                    yes = "https://pastebin.com/raw/" + raw;
                }
                //string ok = Raw1.Text.Replace("https://pastebin.com/raw/", "");
                string text = webclient.DownloadString(yes);
                GetCurrent().Text = text;
                History.Items.Add(yes);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message, "SpiiceNX");
            }
        }

        private void Button_Click_11(object sender, RoutedEventArgs e)
        {
            Process.Start("Bootstrapper.exe");
            this.Close();
        }

        private async void Button_Click_12(object sender, RoutedEventArgs e)
        {
            Main.Opacity = 0;
            DoubleAnimation c = new DoubleAnimation(0, (Duration)TimeSpan.FromSeconds(1));
            c.EasingFunction = new QuarticEase();
            Update.BeginAnimation(FrameworkElement.OpacityProperty, c);
            await Task.Delay(TimeSpan.FromSeconds(2));
            Update.Opacity = 0;
            Update.Visibility = Visibility.Hidden;
            Main.Visibility = Visibility.Visible;
            DoubleAnimation cc = new DoubleAnimation(1, (Duration)TimeSpan.FromSeconds(1));
            cc.EasingFunction = new QuarticEase();
            Main.BeginAnimation(FrameworkElement.OpacityProperty, cc);
            await Task.Delay(TimeSpan.FromSeconds(2));
        }

        private void Button_Click_13(object sender, RoutedEventArgs e)
        {
            api.LaunchExploit();
        }

        private void Button_Click_14(object sender, RoutedEventArgs e)
        {
            string script = GetCurrent().Text;
            api.SendLuaScript(script);
        }

        private void Button_Click_15(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "lua file(*.lua) |*.lua|text file(*.txt) |*.txt";
            dlg.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory + @"scripts\";
            if (dlg.ShowDialog() == true)
            {
                File.WriteAllText(dlg.FileName, GetCurrent().Text);
            }
        }
        //GetCurrent().Text = File.ReadAllText($"./scripts/{list.SelectedItem}");
    }
}
